import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-sidebar',
  templateUrl: './service-sidebar.component.html',
  styleUrls: ['./service-sidebar.component.scss']
})
export class ServiceSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
