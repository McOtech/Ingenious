import { Component, Inject, OnInit } from '@angular/core';
import { CompanyService, Good } from './services/company.service';
import { JQ_TOKEN } from './services/jquery.service';
import { Toastr, TOASTR_TOKEN } from './services/toastr.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Ingenious';
  sservices: Good[];

  constructor(
    @Inject(JQ_TOKEN) private $: any,
    @Inject(TOASTR_TOKEN) private toastr: Toastr,
    private company: CompanyService
  ) {}

  ngOnInit() {
    this.sservices = this.company.getGoods().slice(0, 4);
    this.$('.user').popup({
      inline     : true,
      hoverable  : true,
      position   : 'bottom left',
      delay: {
        show: 300,
        hide: 800
      }
    });
  }
}

// "./node_modules/toastr/build/toastr.min.css",
// "./node_modules/bootstrap/dist/css/bootstrap.min.css",
// "./semantic/dist/semantic.min.css",

// "./node_modules/toastr/build/toastr.min.js",
// "./node_modules/popper.js/dist/umd/popper.min.js",
// "./node_modules/bootstrap/dist/js/bootstrap.min.js",
// "./semantic/dist/semantic.min.js",
